#! /usr/bin/env python

from base64 import encode
import sys

encode(sys.stdin, sys.stdout)
